# -*- coding: utf-8 -*-
"""
Created on Sat Nov 17 19:18:21 2018

@author: swojc
"""

import operator
def read_file(changes_file):
    # use strip to strip out spaces and trim the line.
    data = [line.strip() for line in open(changes_file, 'r')]
    return data

def get_commits(data):
    sep = 72*'-'
    commits = []
    current_commit = None
    index = 0
    while index < len(data):
        try:
            # parse each of the commits and put them into a list of commits
            details = data[index + 1].split('|')
            # the author with spaces at end removed.
            commit = {'revision': details[0].strip(),
                'author': details[1].strip(),
                'date_full': details[2].strip(),
                'date': details[2].strip().split(' ')[0],
                'time': details[2].strip().split(' ')[1],
                'dayofweek': details[2].strip().split(' ')[3].lstrip('('),
                'month': details[2].strip().split(' ')[5].strip(),
                'year': details[2].strip().split(' ')[6].rstrip(')'),
                'number_of_lines': details[3].strip().split(' ')[0]
            }
            # add details to the list of commits.
            commits.append(commit)
            index = data.index(sep, index + 1)
        except IndexError:
            break
    return commits

def get_authors(commits):
    authors = {}
    for commit in commits:
        author = commit['author']
        if author not in authors:
            authors[author] = 1
        else:
            authors[author] = authors[author] + 1
    return authors

if __name__ == '__main__':
    # open the file - and read all of the lines.
    changes_file = 'changes_python.log'
    data = read_file(changes_file)
    commits = get_commits(data)


    # how many commits
    print("Total number of commits: ", len(commits))
    # ==> result is 422




    # how many different people
    authors = {}
    for commit in commits:
        author = commit['author']
        if author not in authors:
            authors[author] = 1
        else:
            authors[author] = authors[author] + 1
    print("Total number of authors: ", len(authors))
    # ==> 10





    # who made the most
    #first, sort the list in reverse mode
    new_sorted_authors = sorted(authors.items(), key=operator.itemgetter(1), reverse=True)
    top_commiter = new_sorted_authors[0]
    lowest_commiter = new_sorted_authors[len(new_sorted_authors)-1]
    print("Top commiter is ", top_commiter[0]) #Thomas
    print("Lowest commiter: ", lowest_commiter[0]) # murari.krishnan





    # taken top person as example, how many commits? 
    print(top_commiter[0],"has commited", top_commiter[1], "times")

    # how many commits per person
    new_sorted_authors = sorted(authors.items(), key=operator.itemgetter(1), reverse=True)
    all_Commiters = new_sorted_authors
    
    print(all_Commiters)
    

    # how many lines a person changed?
    authors = {}
    for commit in commits:
        author = commit['author']
        line = int(commit['number_of_lines'])
        if author not in authors:
            authors[author] = {'author':author, 'commits':1, 'lines':line}
        else:
            total_commits = authors[author]['commits']
            total_lines = authors[author]['lines']
            authors[author] = {'author':author, 'commits':total_commits + 1, 'lines':total_lines + line}

    for author in authors:
        print(author, "has changed ", authors[author]['lines'], "lines")





    # count per month
    months = {}
    for commit in commits:
         month = commit['month']
         if month not in months:
             months[month] = 1
         else:
             months[month] = months[month] +1
    #sort months in reverse mode
    months = sorted(months.items(), key=operator.itemgetter(1), reverse=True)
    #print a list of months and the total
    for month in months:
        print(month[0],"=",month[1],"commits")




    # count per date
    list_of_dates = {}
    for commit in commits:
         date = commit['date']
         if date not in list_of_dates:
             list_of_dates[date] = 1
         else:
             list_of_dates[date] = list_of_dates[date] +1
    #sort dates in reverse mode
    list_of_dates = sorted(list_of_dates.items(), key=operator.itemgetter(1), reverse=True)
    #print a list of dates and the total
    for date in list_of_dates:
        print(date[0],"=",date[1],"commits")



    #the top date
    print("The top date is:", list_of_dates[0][0]," with", list_of_dates[0][1]," commits")


 
