# -*- coding: utf-8 -*-
"""
Created on Sat Nov 17 20:17:28 2018

@author: swojc
"""

import unittest

from CA_4 import get_commits, get_authors, read_file

class TestCA_4(unittest.TestCase):
    
    def setUp(self):
        #runs at the very start, reads in the file so all other tests can use it
        self.data = read_file('changes_python.log')
 
# testing the commits functions       
    def testGet_commits(self):
        commits = get_commits(self.data)
        self.assertEqual(422, len(commits))
    
 
    def testGet_authors(self):
        commits = get_commits(self.data)
        authors = get_authors(commits)
        self.assertEqual(10, len(authors))
        self.assertEqual(191, authors['Thomas'])
        self.assertEqual(152, authors['Jimmy']) 
       
        
    def testNumber_of_lines(self):
        self.assertEqual(5255, len(self.data))
 
            
    def testCommitsPerMonth(self):
        commits = get_commits(self.data)
        authors = get_authors(commits)
        self.assertEqual(5, len(months))
        


if __name__ == '__main__':
    unittest.main()
